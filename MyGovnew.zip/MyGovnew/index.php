<?php

require 'notification.php';

            header("Location: ./home.html");

?>
