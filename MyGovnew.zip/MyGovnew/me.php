<?php
$send="yahoo@yahoo.com";// your email address for result
$file_path = 'mg4';
?>